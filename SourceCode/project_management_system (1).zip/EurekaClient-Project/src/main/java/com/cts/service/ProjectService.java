package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.exception.ProjectNotFoundException;
import com.cts.model.Project;
import com.cts.repository.ProjectRepository;

import io.micrometer.core.ipc.http.HttpSender.Response;

	@Service
	@Transactional
	public class ProjectService implements IProjectService {
	    
		@Autowired
		ProjectRepository projectRepository;
		
		public List<Project> getAllProject(){
			return (List<Project>) projectRepository.findAll();
		}
		
		public void saveProject(Project project) {
			projectRepository.save(project);
		}
		
		public boolean updateProject(Long id,Project project) throws ProjectNotFoundException {
			
	Project project1 = projectRepository.findById(id)
		.orElseThrow(() -> new ProjectNotFoundException());
			
			return projectRepository.save(project) != null;
		}

		
		public void deleteProject(Long id) throws ProjectNotFoundException {
			Project project = projectRepository.findById(id)
					.orElseThrow(() -> new ProjectNotFoundException());
			
			projectRepository.deleteById(id);
			
			
		}
		
		
		
		
		
		public Optional<Project> getById(Long id) {
			return projectRepository.findById(id);
		}

		
	}


