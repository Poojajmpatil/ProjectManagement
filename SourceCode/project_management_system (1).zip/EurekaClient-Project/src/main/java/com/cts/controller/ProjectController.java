package com.cts.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.exception.ProjectNotFoundException;
import com.cts.model.Project;
import com.cts.service.IProjectService;


@RestController
public class ProjectController {
	
	@Autowired
	IProjectService iProjectService;
	
	@GetMapping("/projects")
	public List<Project> getAllProject(){
		return iProjectService.getAllProject();
	}
	
	@PostMapping("/project")
	public void saveProject(@RequestBody Project project) {
		iProjectService.saveProject(project);
	}
	

	@PutMapping(value = "/project/{id}")
	public HttpStatus updateProject(@PathVariable Long id,@RequestBody Project project) {
		
		return iProjectService.updateProject(id,project)  ? HttpStatus.ACCEPTED : HttpStatus.BAD_REQUEST;
	}
	
	
	
	@RequestMapping(value = "/project/{id}", method = RequestMethod.DELETE)
	public HttpStatus deleteProject(@PathVariable Long id) {
		iProjectService.deleteProject(id);
		return HttpStatus.NO_CONTENT;
	
	}

	@GetMapping("/project/{id}")
	public Optional<Project> getById(@PathVariable Long id) {
	    return iProjectService.getById(id) ;
	}
	
	
	
}