package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.cts.model.Project;

public interface IProjectService {
	
	public List<Project> getAllProject();
	public void saveProject(@RequestBody Project project);
	public boolean updateProject(@PathVariable Long id,@RequestBody Project project);
	public void deleteProject(Long id);
	public Optional<Project> getById(Long id);
	

}

