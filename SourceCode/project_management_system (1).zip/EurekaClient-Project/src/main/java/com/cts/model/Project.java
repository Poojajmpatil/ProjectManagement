package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.ToString;


@Entity
@Table(name = "Project")

@Data
@NoArgsConstructor
@ToString
@AllArgsConstructor
@NonNull
public class Project {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long project_id;
	private String project_name;
    private String description;
    private String project_head;
    private String start_date;
    private String end_date;
    

//	public Long getProject_id() {
//		return project_id;
//	}
//
//	public void setProject_id(Long project_id) {
//		this.project_id = project_id;
//	}
//
//	public String getProject_name() {
//		return project_name;
//	}
//
//	public void setProject_name(String project_name) {
//		this.project_name = project_name;
//	}
//
//	public String getDescription() {
//		return description;
//	}
//
//	public void setDescription(String description) {
//		this.description = description;
//	}
//
//	public String getProject_head() {
//		return project_head;
//	}
//
//	public void setProject_head(String project_head) {
//		this.project_head = project_head;
//	}
//
//	public String getStart_date() {
//		return start_date;
//	}
//
//	public void setStart_date(String start_date) {
//		this.start_date = start_date;
//	}
//
//	public String getEnd_date() {
//		return end_date;
//	}
//
//	public void setEnd_date(String end_date) {
//		this.end_date = end_date;
//	}
//
//	public Project() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//	public Project(Long project_id, String project_name, String description, String project_head, String start_date,
//			String end_date) {
//		super();
//		this.project_id = project_id;
//		this.project_name = project_name;
//		this.description = description;
//		this.project_head = project_head;
//		this.start_date = start_date;
//		this.end_date = end_date;
//	}
//    
//	@Override
//	public String toString() {
//		return "Project [project_id=" + project_id + ", project_name=" + project_name + ", description=" + description
//				+ ", project_head=" + project_head + ", start_date=" + start_date + ", end_date=" + end_date + "]";
//	}
	}
    
    
    

