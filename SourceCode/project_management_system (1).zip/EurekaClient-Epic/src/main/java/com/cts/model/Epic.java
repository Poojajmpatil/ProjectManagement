package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.ToString;



@Entity
@Table(name = "Epic")


@Data
@NoArgsConstructor
@ToString
@AllArgsConstructor
@NonNull
public class Epic {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long epic_id;
	private Long project_id;
	private String objective;
	private String start_date;
	private String end_date;
	

}
