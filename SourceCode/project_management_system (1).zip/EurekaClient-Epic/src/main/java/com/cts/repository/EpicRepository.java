package com.cts.repository;

import org.springframework.data.repository.CrudRepository;

import com.cts.model.Epic;

public interface EpicRepository extends CrudRepository<Epic, Long> {

}
