package com.cts.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


@RestControllerAdvice
public class EpicExceptionController {
		@org.springframework.beans.factory.annotation.Value("${epic_not_found}")

		private String epicNotFound;

	@ExceptionHandler(value= EpicNotFoundException.class)
		public ResponseEntity<Object> exception(EpicNotFoundException exception)
		{
			return new ResponseEntity<>(epicNotFound,HttpStatus.NOT_FOUND);
		}

	}