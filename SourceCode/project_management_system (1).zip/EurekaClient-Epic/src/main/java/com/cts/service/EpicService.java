package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.exception.EpicNotFoundException;
import com.cts.model.Epic;
import com.cts.repository.EpicRepository;


@Service
@Transactional
public class EpicService implements IEpicService  {
	
	@Autowired
	EpicRepository epicRepository;
	
	public List<Epic> getAllEpic(){
		return (List<Epic>) epicRepository.findAll();
	}
	
	public void saveEpic(Epic epic) {
		epicRepository.save(epic);
	}
	
	public boolean updateEpic(Long id,Epic epic) throws EpicNotFoundException {
		
		Epic epic1 = epicRepository.findById(id)
	.orElseThrow(() -> new EpicNotFoundException());
		
		return epicRepository.save(epic) != null;
	}

	
	public void deleteEpic(Long id) throws EpicNotFoundException {
		Epic epic = epicRepository.findById(id)
				.orElseThrow(() -> new EpicNotFoundException());
		
		epicRepository.deleteById(id);
			
	}
	
	public Optional<Epic> getById(Long id) {
		return epicRepository.findById(id);
	}

	
}

