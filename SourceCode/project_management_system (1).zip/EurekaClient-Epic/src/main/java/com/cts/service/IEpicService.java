package com.cts.service;

import java.util.List;
import java.util.Optional;

import com.cts.model.Epic;



public interface IEpicService {

	public List<Epic> getAllEpic();
	public void saveEpic(Epic epic);
	public boolean updateEpic(Long id,Epic epic);
	public void deleteEpic(Long id);
	public Optional<Epic> getById(Long id);
}
