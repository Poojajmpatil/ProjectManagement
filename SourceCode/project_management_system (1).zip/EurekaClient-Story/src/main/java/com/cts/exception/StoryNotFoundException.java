package com.cts.exception;

public class StoryNotFoundException extends RuntimeException {
	private static final long serialVersionUID  = 1L;

}
